package testing;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class WindowsExample {

	public static void main(String[] args) {

		// Chrome Profiling
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
		// System.setProperty("webdriver.chrome.driver",".\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.naukri.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String mainwindow = driver.getWindowHandle();
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();

		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
				// driver.switchTo().window(ChildWindow);
				driver.switchTo().window(ChildWindow);
				driver.close();
				System.out.println("Child window closed");
				driver.switchTo().window(mainwindow);
				System.out.println("Moved to Main Window");
				WebElement recruiters = driver.findElement(By.xpath("//*[@id='root']/div[1]/div/ul[1]/li[2]/a/div"));

				// Creating object of an Actions class
				Actions action = new Actions(driver);

				// Performing the mouse hover action on the target element.
				action.moveToElement(recruiters).perform();

				WebElement browseall = driver.findElement(By.xpath("//*[@id='root']/div[1]/div/ul[1]/li[2]/div/ul/li[1]/a"));
				browseall.click();
				System.out.println("clicked on Browse All");
			}
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				for(String w1 : driver.getWindowHandles()) {
					driver.switchTo().window(w1);
					WebElement tools = driver.findElement(By.xpath("//div[contains(text(),'Tools')]"));
					Actions action = new Actions(driver);
					action.moveToElement(tools).perform();
					WebElement dashboard = driver.findElement(By.xpath("//li/a[contains(text(),'Career Dashboard')]"));

					dashboard.click();
					System.out.println("moved to W1 and clicked on Dashboard");
				}
				for(String w2 : driver.getWindowHandles()) {
					driver.switchTo().window(w2);
					driver.findElement(By.xpath("//*[@id='login_Layer']/div")).click();
					driver.findElement(By.xpath("//*[@id='root']/div[2]/div[2]/div/form/div[2]/input"))
							.sendKeys("juhitram@gmail.com");
					driver.findElement(By.xpath("//*[@id='root']/div[2]/div[2]/div/form/div[3]/input"))
							.sendKeys("HEMA1996");
					driver.findElement(By.xpath("//*[@id='root']/div[2]/div[2]/div/form/div[6]/button")).click();
					driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);

					driver.close();

				}
				
				
								driver.switchTo().window(mainwindow);
				//

				// WebElement text =
				// driver.findElement(By.xpath("//*[@id='root']/main/div[2]/div[2]/section[1]/div[1]/div[3]/div/button[2]"));
				// System.out.println("Heading of child window is " + text.getText());
				// driver.close();
				// System.out.println("Child window closed");
			
		}

	}

}
